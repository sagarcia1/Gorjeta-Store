//
//  Entity.m
//  gorjeta
//
//  Created by Marcelo Garcia on 25/02/14.
//  Copyright (c) 2014 Celo. All rights reserved.
//

#import "Entity.h"


@implementation Entity

@dynamic categoria;
@dynamic valor_total;
@dynamic valor_pessoa;

@end
