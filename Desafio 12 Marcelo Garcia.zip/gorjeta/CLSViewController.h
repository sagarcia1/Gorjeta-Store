//
//  CLSViewController.h
//  gorjeta
//
//  Created by Celo on 17/12/13.
//  Copyright (c) 2013 Celo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLSViewController : UIViewController<UIPickerViewDelegate,UIPickerViewDataSource,UINavigationControllerDelegate>// protocolos que serao usados para a picker
{
    NSMutableArray *listaqtd;//array para receber a picker
    NSMutableArray *segundalista;
    
    
}
- (IBAction)btPrefer:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerCategoria;
- (IBAction)btSalvar:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblCateg;
- (IBAction)SwitchTrocaCor:(UISwitch *)sender;
@property (strong, nonatomic) IBOutlet UISwitch *switchTroca;
- (IBAction)btLogoff:(UIButton *)sender;
- (IBAction)btPreference:(UIButton *)sender;
@property (nonatomic,strong) NSString *cat;
@property (nonatomic,strong)NSManagedObjectContext *context1;
@property (weak, nonatomic) IBOutlet UILabel *gorjeta;
@property (weak, nonatomic) IBOutlet UILabel *valorGorjeta;
@property (weak, nonatomic) IBOutlet UILabel *valorTotal;
@property (weak, nonatomic) IBOutlet UILabel *subPessoa;
@property (weak, nonatomic) IBOutlet UILabel *valorPessoa;
@property (weak, nonatomic) IBOutlet UILabel *totalPessoa;
@property (weak, nonatomic) IBOutlet UILabel *numPessoa;

@end
