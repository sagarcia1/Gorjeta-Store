//
//  CLSPreferencesViewController.h
//  gorjeta
//
//  Created by Celo on 23/02/14.
//  Copyright (c) 2014 Celo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLSPreferencesViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
- (IBAction)btVolta:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UISwitch *SwitchCor;


@end
