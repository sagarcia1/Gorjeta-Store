//
//  CLSPreferencesViewController.m
//  gorjeta
//
//  Created by Celo on 23/02/14.
//  Copyright (c) 2014 Celo. All rights reserved.
//

#import "CLSPreferencesViewController.h"
#import "CLSViewController.h"
#import "Entity.h"
#import "CLSAppDelegate.h"
#import <CoreData/CoreData.h>
#import "CLSRelatorioViewController.h"

@interface CLSPreferencesViewController ()
{
    NSArray *fetchedObjects;

}

@end

@implementation CLSPreferencesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self getFetch];
    
        
    }
    

-(void)getFetch{
  

     NSManagedObjectContext *context1 = [(CLSAppDelegate *)[[UIApplication sharedApplication]delegate]managedObjectContext ];
    
    NSEntityDescription *entity1 = [NSEntityDescription entityForName:@"Entity" inManagedObjectContext:context1];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc]init];
    [fetchRequest setEntity:entity1];
//    Entity *catValor;
//    
//        NSPredicate *pred = [NSPredicate predicateWithFormat:@"valor_pessoa==%@",catValor.valor_pessoa];
//      [fetchRequest setPredicate:pred];
    NSError *error;
   fetchedObjects = [context1 executeFetchRequest:fetchRequest error:&error];
    for (Entity *cat in fetchedObjects ) {
        NSLog(@"VAlOR PESSOA busca %@",cat.valor_pessoa);
        NSLog(@"VALOR TOTAL busca %@",cat.valor_total);
        

    
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btVolta:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return [fetchedObjects count];
    
 
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    
    if (!cell) {
    
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    Entity *info = [fetchedObjects objectAtIndex:indexPath.row];
    cell.textLabel.text = info.categoria;
    return cell;


}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    Entity *info = [fetchedObjects objectAtIndex:indexPath.row];

    CLSRelatorioViewController *preference = (CLSRelatorioViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"CLSRelatorioViewController"];
    [self presentViewController:preference  animated:YES completion:nil];
    preference.textFieldValorPessoa.text = info.valor_pessoa;
    preference.textFieldValorTotal.text = info.valor_total  ;
    
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSManagedObjectContext *context1 = [(CLSAppDelegate *)[[UIApplication sharedApplication]delegate]managedObjectContext ];

        NSManagedObject *delete = [fetchedObjects objectAtIndex:indexPath.row];
        [context1 deleteObject:delete];
        NSError *error;
        [context1 save:&error];
    
       // [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [tableView reloadData];
        
        
        
    }
    }


@end
