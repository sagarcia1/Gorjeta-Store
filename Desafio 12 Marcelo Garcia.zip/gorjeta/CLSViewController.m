//
//  CLSViewController.m
//  gorjeta
//
//  Created by Celo on 17/12/13.
//  Copyright (c) 2013 Celo. All rights reserved.
//

#import "CLSViewController.h"
#import "CLSLoginViewController.h"
#import "CLSPreferencesViewController.h"
#import "CLSCategoriasViewController.h"
#import "CLSAppDelegate.h"
#import "CLSSettingsViewController.h"
#import <Security/Security.h>
#import "Entity.h"

@interface CLSViewController ()
@property (weak, nonatomic) IBOutlet UITextField *subTotal;

@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (strong, nonatomic) IBOutlet UIPickerView *picker;
@property (strong,nonatomic) NSMutableArray *content;
- (IBAction)mudarSlider:(id)sender;

@end

@implementation CLSViewController
-(void)reset{
    _subTotal.text=@"";
    _slider.value=0;
    _gorjeta.text=@"";
    _valorTotal.text=@"";
    _valorGorjeta.text=@"";
    _totalPessoa.text=@"";
}
- (IBAction)btnReset:(UIButton *)sender {

    [self reset];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSString *teste;
    
    
    NSString *fontStyle;
    float fontValue= [defaults floatForKey:@"fontSize"];
    fontStyle = [defaults objectForKey:@"fontStyle"];
    
    [self.valorGorjeta setFont:[UIFont fontWithName:fontStyle size:fontValue]];
     [self.lblCateg setFont:[UIFont fontWithName:fontStyle size:fontValue]];
     [self.valorPessoa setFont:[UIFont fontWithName:fontStyle size:fontValue]];
     [self.valorTotal   setFont:[UIFont fontWithName:fontStyle size:fontValue]];
    
    
    
    
    

    self.lblCateg.text = self.cat;
    NSLog(@"%@Parametro",self.cat);
    
    
    bool trocaCor = [defaults boolForKey:@"SwitchCor"];
    NSLog(@"%@STRING",teste);
    
    NSManagedObjectContext *categoriaObj = [(CLSAppDelegate *)[[UIApplication sharedApplication]delegate]managedObjectContext ];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
	NSEntityDescription *entity = [NSEntityDescription entityForName:@"Entity" inManagedObjectContext:categoriaObj];
	[fetchRequest setEntity:entity];
    
    
    self.pickerCategoria.tag = 12;
  
    _picker.tag = 11;
    
    
        if (trocaCor ==YES) {
          
            self.view.backgroundColor = [[UIColor alloc]initWithPatternImage:
                                         [UIImage imageNamed: @"fundoverdinho"]];
            
        }
        else {
            
            self.view.backgroundColor = [[UIColor alloc]initWithPatternImage:[UIImage imageNamed:@"fundoroxinho"]];
        }
   
    


     _content= [[NSMutableArray alloc]initWithContentsOfFile:[[NSBundle mainBundle]pathForResource:@"Categorias" ofType:@"plist"]];
    listaqtd = [[NSMutableArray alloc] initWithObjects:@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",nil];//cria o array que vai receber numeros de 0 a 9
    segundalista = [[NSMutableArray alloc] initWithObjects:@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",nil];//segundo array para inicializar o picker em 1
    
    [self    CalculoSubtotal];
    [self TotalPessoa];
    [self Calculototal];
    [self CalculoGorjeta];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)mudarSlider:(id)sender {
    int valorSlider = _slider.value;//recebe o valor do slider como um intero
    NSString *stringslider = [[NSString alloc]initWithFormat:@"%i",valorSlider];//tranforma o valor int em uma string
    _gorjeta.text = stringslider;
    
    [self CalculoGorjeta];
   [self    CalculoSubtotal];
    [self Calculototal];
    [self TotalPessoa];
    
    [self.subTotal resignFirstResponder];
    
    
}

#pragma mark metodos

-(void)Calculototal
{
    float calcTotal =[_subTotal.text floatValue] + [_valorGorjeta.text floatValue];
    
    NSString *totalStr = [[NSString alloc]initWithFormat:@"%.2f",calcTotal ];
    
    _valorTotal.text = totalStr;
}//metodo que retorna o valor total

-(void) CalculoGorjeta
{
    float calcGorjeta = [_subTotal.text floatValue] *[_gorjeta.text intValue]/100;//calcula gorgeta
    NSString *calcGorjetastr = [[NSString alloc]initWithFormat:@"%.2f",calcGorjeta];
    _valorGorjeta.text = calcGorjetastr;
}

-(void) CalculoSubtotal
{
    float subTotal = [_subPessoa.text floatValue]/[_numPessoa.text intValue];
    NSString *subTotal1 = [[NSString alloc]initWithFormat:@"%.2f",subTotal];
    _subPessoa.text = subTotal1;
    
}


-(void) TotalPessoa
{
    float Total = [_valorTotal.text floatValue]/[_numPessoa.text intValue];
    NSString *total1=[[NSString alloc]initWithFormat:@"%.2f", Total];
    _totalPessoa.text=total1;
}
//metodo obrigatorio para contar o numero de componentes da pickerview
//retorna o numero de linhas do picker

#pragma mark delegates

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{   int valueReturn;
    if ([pickerView isEqual:self.pickerCategoria]) {
        valueReturn = 1;
    }
    if ([pickerView isEqual:_picker]) {
        valueReturn = 2;
    }
    return valueReturn;
    // cria 2 componentes da picker
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    int aux;
    if (pickerView.tag ==11) {
        
    
    if (component == 0 ) {// se o componente estiver em  0 o aux  vai receber a lista do primeiro picker
        aux = [listaqtd count];
    }
    
    if (component == 1 ) {
        aux=[segundalista count]; // senao o aux recebe a segunda lista
    }
    
     
    }
    if (pickerView.tag ==12) {
        aux = [_content count];
    }
    return aux;
    
}//metodo obrigatorio que retorna o valor do nsmutable
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
//ele passa o row e o componente como parametro, e faz o mesmo if para verificar se esta na primeira ou na segunda picker
    NSString *aux;
    if (pickerView.tag ==11) {
        if (component == 0 ) {
            aux=[listaqtd objectAtIndex:row];
        }
        if (component ==1 )
        {
            aux=[segundalista objectAtIndex:row];
        }
        

    }
    if (pickerView.tag ==12) {
        aux = [[_content objectAtIndex:row]valueForKey:@"Categoria"];
    }
        return aux;
    NSLog(@"O que ta pegando no aux %@",aux);
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    if (pickerView.tag ==11) {
        
    
    NSMutableString *aux=[[NSMutableString alloc]initWithFormat:self.numPessoa.text];
    if (component == 0 ) {
        [aux replaceCharactersInRange:NSMakeRange(0,1) withString:[listaqtd objectAtIndex:row]];
        //se for selecionado o componente 0  ele colocar o numero selecionado no range 0 da string na tela
      		 // NSAttributedString *attString = [[NSAttributedString alloc] initWithString:aux attributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    }
    
    if (component == 1 ) {
        [aux replaceCharactersInRange:NSMakeRange(1,1) withString:[segundalista objectAtIndex:row]];
        //se for selecionado o componente 0  ele colocar o numero selecionado no range 1 da string na tela
        // e escolhe da segunda lista pois foi trocado e o valor inicial dela e 1
        
        
    }
    
    _numPessoa.text = aux;//recebe o valor editado dos pickers
    [self    CalculoSubtotal];
    [self TotalPessoa ];
    }
    if (pickerView.tag ==12){
        NSString *cat1 = [[_content objectAtIndex:row]valueForKey:@"Categoria"];
        self.cat =[NSString stringWithFormat:@"%@",cat1];
        
        NSLog(@"valor cat %@",self.cat);
    }
    
}//metodo para quando a picker for selecionada

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
    [self Calculototal];
    [self CalculoSubtotal];
    [self CalculoGorjeta];
    [self TotalPessoa];
}

- (IBAction)btLogoff:(UIButton *)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)btPreference:(UIButton *)sender {
    CLSPreferencesViewController *preference = (CLSPreferencesViewController *)[self.storyboard instantiateViewControllerWithIdentifier:@"CLSPreferencesViewController"];
    [self presentViewController:preference  animated:YES completion:nil];
}
- (IBAction)btSalvar:(UIButton *)sender {
    
    [self salvar];
    [self reset];
    
    
    
        
        
    
}

-(void)salvar
{
   	NSManagedObjectContext *context = [(CLSAppDelegate *)[[UIApplication sharedApplication] delegate] managedObjectContext];

    Entity *valorTotal = (Entity *)[NSEntityDescription insertNewObjectForEntityForName:@"Entity" inManagedObjectContext:context];

    valorTotal.valor_total = self.valorTotal.text;
    valorTotal.valor_pessoa = self.totalPessoa.text;
    valorTotal.categoria = self.cat;
    NSError *error;
    [context save:&error];
    UIAlertView *salvou =[[UIAlertView alloc]initWithTitle:@"SALVOU" message:@"SALVO COM SUCESSO" delegate:self cancelButtonTitle:@"FEITO" otherButtonTitles:nil, nil];
    [salvou show];
}
    


- (IBAction)btPrefer:(UIButton *)sender {
    CLSSettingsViewController *set = (CLSSettingsViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"CLSSettingsViewController"];
    [self presentViewController:set animated:YES completion:nil];
}
@end
