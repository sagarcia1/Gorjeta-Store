//
//  CLSCategoriasViewController.h
//  gorjeta
//
//  Created by Celo on 24/02/14.
//  Copyright (c) 2014 Celo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CLSCategoriasViewController : UIViewController<UITableViewDataSource,UITableViewDelegate >
@property (strong, nonatomic) IBOutlet UITableView *tabeview;NSString;
@property (strong,nonatomic)NSString *passa ;


@end
